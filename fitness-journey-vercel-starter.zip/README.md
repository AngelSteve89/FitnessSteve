# Fitness Journey — Vercel + Vite + React + PWA Starter

**How to publish (no coding tools needed):**
1) Unzip this folder.
2) Go to your GitHub repo → **Add file → Upload files** → drag all files/folders from this unzipped folder → **Commit**.
3) In Vercel: Import the repo (Framework: **Vite**). Build: `npm run build`. Output: `dist`.
4) Open the URL Vercel gives you. On your phone: Add to Home Screen.

Replace `src/App.jsx` with your real app when you’re ready.
