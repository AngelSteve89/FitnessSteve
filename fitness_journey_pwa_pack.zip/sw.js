const CACHE_NAME = 'fitjourney-cache-v1';
const STATIC_ASSETS = [
  '/', '/index.html',
  '/manifest.webmanifest'
  // Add built CSS/JS paths after your first deploy if needed.
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

// Network-first for navigation requests (SPA)
self.addEventListener('fetch', (event) => {
  const req = event.request;

  // HTML navigations: network first
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).then(res => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then(cache => cache.put('/', resClone));
        return res;
      }).catch(async () => {
        const cache = await caches.open(CACHE_NAME);
        return cache.match('/') || cache.match('/index.html');
      })
    );
    return;
  }

  // Cache-first for same-origin static assets
  if (req.method === 'GET' && new URL(req.url).origin === location.origin) {
    event.respondWith(
      caches.match(req).then((cached) => {
        return cached || fetch(req).then((res) => {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          return res;
        });
      })
    );
  }
});
