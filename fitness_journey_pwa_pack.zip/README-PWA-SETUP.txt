PWA Setup Pack — Fitness Journey Tracker

Files included:
- public/manifest.webmanifest        → PWA manifest
- public/icons/*                     → App icons used by devices
- /sw.js                             → Service worker
- src/registerServiceWorker.js       → Small helper to register SW
- vercel.json                        → SPA routing for Vercel

How to integrate (React/Vite/Cra):
1) Copy everything in this pack into your project:
   - Merge `public/` contents into your project's `public/`
   - Put `sw.js` at project root (so it deploys at /sw.js), OR move to `public/` and change registration path to '/sw.js' accordingly.
   - Put `src/registerServiceWorker.js` into your `src/` folder.

2) Link the manifest in your main HTML (usually public/index.html for CRA or index.html for Vite):
   <link rel="manifest" href="/manifest.webmanifest" />
   <meta name="theme-color" content="#0b1220" />

3) Import & call the registration once in your app entry (e.g., src/main.jsx or src/index.tsx):
   import { registerServiceWorker } from './registerServiceWorker';
   registerServiceWorker();

4) Build & serve over HTTPS (Vercel/Netlify do this by default).
   After your first deploy, visit on mobile, use browser menu → "Add to Home Screen". The app will launch fullscreen thereafter.

5) Optional tweaks:
   - Update manifest name/description/colors.
   - Replace icons with your own (keep same sizes/filenames).
   - If your app is hosted in a subpath, set `start_url` and `scope` to that subpath.

Vercel deploy (Option 1):
   - Push project to GitHub, then "Import Project" on vercel.com
     or use "Deploy Project" and drag-and-drop your folder.
   - Ensure vercel.json is at the project root for SPA routing.
   - After deploy, open the site on a phone → Add to Home Screen.

Cache strategy:
   - HTML navigations are network-first (fresh content when online).
   - Static assets are cache-first (fast loads, works offline).
   - Update CACHE_NAME in sw.js to bust old caches when you ship big changes.
